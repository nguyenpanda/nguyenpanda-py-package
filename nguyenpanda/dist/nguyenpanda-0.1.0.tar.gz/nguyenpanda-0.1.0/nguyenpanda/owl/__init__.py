# from .color import Color

__all__ = [
    # 'color',
]

__version__ = '0.1.0'

__title__ = 'owl'

__description__ = '''
\'owl\' package provides things related to mathematics
'''
