from .uniform import Uniform

__all__ = [
    'Uniform',
]

__version__ = '0.1.0'

__title__ = 'butterfly'

__description__ = '''
\'butterfly\' package provides things related to random, uncertainty, chaos
'''
