import requests
import json

'''
Int, IntSeq, Dec, Gauss, Str, 

apiKey
n

min (Int
max (Int
length (Int, IntSeq, str
decimalPlaces (DecimalFractions
mean, standardDeviation, significantDigits (Gaussians
characters (str
size (Blobs

replacement
base
pregeneratedRandomization
format
'''


class RealRandom():
    def __init__(self, api_key: str | None = None, *args, **kwargs):
        pass


if __name__ == '__main__':
    a = {'a': 1,
         'b': 2}

    print(str(a))
