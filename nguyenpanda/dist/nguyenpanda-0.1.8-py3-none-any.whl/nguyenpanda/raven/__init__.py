"""
🐦‍⬛ raven
    Enter the realm of the raven, where intelligence and innovation
    converge in a comprehensive library of data structures
    Inspired by the ingenuity of the raven, this package offers elegant data structures classes.
"""